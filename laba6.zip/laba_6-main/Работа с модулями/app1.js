const welcome = require('./welcome');

welcome.getMorningMessage();
welcome.getEveningMessage();
