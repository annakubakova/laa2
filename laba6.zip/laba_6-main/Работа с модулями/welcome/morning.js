module.exports = 'Доброе утро';
