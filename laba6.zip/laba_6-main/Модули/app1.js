const User = require('./user.js');

let eugene = new User('Milana', 17);
eugene.sayHi();
