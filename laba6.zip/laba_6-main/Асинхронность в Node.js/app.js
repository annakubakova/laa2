function displaySync(data) {
    console.log(data);
}

console.log('Начало работы программы');

displaySync('Обработка данных...');

console.log('Завершение работы программы');
