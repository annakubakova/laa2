const greeting = require('./greeting');

global.name = 'Milana';

global.console.log(date);
console.log(greeting.getMessage());
